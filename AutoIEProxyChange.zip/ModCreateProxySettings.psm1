﻿#********************************************************
# Date:    20 January 2012
# Author:  Les Fleming
# Summary: A powershell module which updates IE-Proxy
#          settings and notifies IE instances of 
#          a change to the proxy settings.        
#********************************************************

$Path = "C:\Temp\IEProxySettings\\"
$Module="ModReadProxySettings.psm1"

function CreateProxySettings
{
    param([string]$Proxy,[string]$Port,[string] $IgnoreProxyFor)

    # Importing of the module responsible for the loading of the assembly file 
    # which notifies IE of proxy changes.
    Import-Module $Path$Module


    #Updating of the Registry with new proxy details.
    Set-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable -Value 1
    Set-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyServer $Proxy':'$Port #your proxy server and port
    Set-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyBypassLocalAddress -Value 1
    Set-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name AutoConfigUrl -Value "" #Disable the use of the Automatic Configuration Script
    Set-Itemproperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -name ProxyOverride -Value $IgnoreProxyFor

    # Invoke the ReadProxySettings Method of the Import-Module 'ModReadSettings'
    ReadProxySettings
}
