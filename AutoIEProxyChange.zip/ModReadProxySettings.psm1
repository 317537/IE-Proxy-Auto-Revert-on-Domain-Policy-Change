﻿#***********************************************************
# Created:   23rd Jan 2012
# Developer: Les Fleming
# Summary:   A module that loads the assembly (C#)
#            which uses the System.Runtime.InteropServices
#            to import WinInet.dll to notify running
#            instances of IE that a change to the proxy
#            settings has occured. 
#***********************************************************


function ReadProxySettings
{
    
    # Declare a string variable which contains the C# source code which forces
    # IE to re-read the proxy settings.

    #Using Reflection to dynamically load the contents of my assembly.
    [Reflection.Assembly]::LoadFile("C:\Temp\IEProxySettings\IEProxyRefresh.dll")
     
    # Invoke the RefreshIEProxySettings Method/Function in the assembly.
    # [Namespace.class]::method()
    [IEProxyRefresh.ReadProxySettings]::RefreshIEProxySettings()
}