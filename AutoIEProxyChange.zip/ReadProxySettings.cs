﻿using System;
using System.Runtime.InteropServices;

namespace IEProxyRefresh
{
    public static class ReadProxySettings
    {
        [DllImport("wininet.dll", SetLastError = true, CharSet = CharSet.Auto)]


        // private static extern bool
        private static extern void InternetSetOption(
          IntPtr hInternet,
          SET_OPTIONS option,
          IntPtr buffer,
          int bufferLength);

        private enum SET_OPTIONS
        {
            /*
             *  INTERNET_OPTION_REFRESH 37 
             *  Causes the proxy data to be reread from the registry for a handle. No buffer is required. 
             *  This option can be used on the HINTERNET handle returned by InternetOpen. It is used by InternetSetOption.
             *  
             *  INTERNET_OPTION_SETTINGS_CHANGED 39 
             *  Notifies the system that the registry settings have been changed so that it verifies the settings on the 
             *  next call to InternetConnect. This is used by InternetSetOption.
             *  
             *  INTERNET_OPTION_PER_CONNECTION_OPTION 75 
             *  Sets or retrieves an INTERNET_PER_CONN_OPTION_LIST structure that specifies a list of options for a 
             *  particular connection. This is used by InternetQueryOption and InternetSetOption.
            */
            INTERNET_OPTION_REFRESH = 37,
            INTERNET_OPTION_SETTINGS_CHANGED = 39,
            INTERNET_OPTION_PER_CONNECTION_OPTION = 75
        };


        public static void RefreshIEProxySettings()
        {
            InternetSetOption(IntPtr.Zero, SET_OPTIONS.INTERNET_OPTION_SETTINGS_CHANGED, IntPtr.Zero, 0);
            InternetSetOption(IntPtr.Zero, SET_OPTIONS.INTERNET_OPTION_REFRESH, IntPtr.Zero, 0);
        }

    }
}
