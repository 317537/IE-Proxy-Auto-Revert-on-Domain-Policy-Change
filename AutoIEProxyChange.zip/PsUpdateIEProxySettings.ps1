﻿#********************************************************************
# Created:   23rd January 2012
# Developer: Leslie Fleming
# Summary:   A powershell script for the auto updating of the proxy
#            settings in IE. This script creates a scheduled
#            task under the current logged on user account
#            which runs at a timed interval ($TaskInterval) and 
#            updates the proxy settings of Internet Explorer. It also 
#            notifies running instances of IE of a change to the proxy 
#            settings, eliminating the need for closing IE in order
#            for the updates to be re-read.
#
#            The update to the proxy settings of Internet Explorer 
#            is actioned by a scheduled task which invokes a vbScript
#            file. This is done in order for the update process to
#            remain hidden, as the taskeng.cmd window will pop up
#            when the task is run under the current logged in 
#            user account.
#            
#            This entire exercise was done, in response to a domain
#            policy disabling the proxy settings in the Dev Preview
#            of Windows 8.          
#********************************************************************



# Declaration of Environment Variables
$User = [Environment]::UserName
$Domain = [Environment]::UserDomainName + "\"
$TaskName = "IEProxyUpdateWin8"
$TaskInterval = "5" #minutes
$Proxy = "1.1.1.1"
$Port = "80"
$IgnoreProxyFor="10.0.*.*;172.*.*.*;192.168.1.*;192.168.2.*;<local>"
$Path = "C:\Temp\IEProxySettings\\"
#$ScriptName = "InternetExplorerEnableProxySettings.ps1"
$RunScript="Proxy.vbs"
$Module="ModCreateProxySettings.psm1"

#Import Module responsible for the creation of the proxy settings.
Import-Module $Path$Module


#schtasks /create /tn <TaskName> /tr <TaskRun> /sc minute [/mo {1 - 1439}] [/st <HH:MM>] [/sd <StartDate>] [/ed <EndDate>] [{/et <HH:MM> | /du <HHHH:MM>} [/k]] [/it] [/ru {[<Domain>\]<User> [/rp <Password>] | System}] [/s <Computer> [/u [<Domain>\]<User> [/p <Password>]]]
#$Command="schtasks.exe /Create /TN $TaskName /RU $Domain$User /SC minute /mo $TaskInterval /TR `"Powershell.exe -executionpolicy unrestricted -file $Path$ScriptName`""
$Command="schtasks.exe /Create /TN $TaskName /RU $Domain$User /SC minute /mo $TaskInterval /TR `"$Path$RunScript`""

 
#Read the current task schedule information and grep (regex) for the known schedule name
 $TaskExists = invoke-expression "cmd.exe /c schtasks.exe /Query" |where {$_ -match  $TaskName}


 If(!$TaskExists)
 {
     #Create a new scheduled tasks if it does not already exists
     invoke-expression "cmd.exe /c $Command"
     CreateProxySettings $Proxy $Port $IgnoreProxyFor
 }
 else
 {

     #Write-Output "Scheduled Task '$TaskName' already exists"
     CreateProxySettings $Proxy $Port $IgnoreProxyFor
 }


